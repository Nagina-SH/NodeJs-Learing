0.1.0 / 2015-03-12
==================

* Fix for issue #5: convert all strings to utf-8

0.0.5 / 2014-05-19
==================

* Added ArrayBuffer support

0.0.4 / 2014-04-25
==================

* Fixed undefined Buffer in browsers

0.0.3 / 2014-03-21
==================

* fixed update() on values < 16

0.0.2 / 2014-01-19
==================

* added tests
* updated README

0.0.1 / 2014-01-01
==================

* Improved performance on large inputs (112Mb sample file in 4s instead of 4.6s)

0.0.0 / 2013-12-31
==================

* Initial release
