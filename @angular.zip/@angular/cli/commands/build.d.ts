import { BuildOptions } from '../models/build-options';
export declare const baseBuildCommandOptions: any;
export interface BuildTaskOptions extends BuildOptions {
    statsJson?: boolean;
}
declare const BuildCommand: any;
export default BuildCommand;
