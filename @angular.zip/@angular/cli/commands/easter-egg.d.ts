declare const MakeThisAwesomeCommand: any;
export default MakeThisAwesomeCommand;
