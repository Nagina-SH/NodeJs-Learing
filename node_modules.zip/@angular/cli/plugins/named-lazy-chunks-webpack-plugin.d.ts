import * as webpack from 'webpack';
export declare class NamedLazyChunksWebpackPlugin extends webpack.NamedChunksPlugin {
    constructor();
}
