export interface UpdateOptions {
    schematic?: boolean;
}
declare const UpdateCommand: any;
export default UpdateCommand;
