export interface DocOptions {
    search?: boolean;
}
declare const DocCommand: any;
export default DocCommand;
